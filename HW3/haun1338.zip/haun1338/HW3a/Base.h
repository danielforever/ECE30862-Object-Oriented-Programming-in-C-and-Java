#ifndef BASE_H_
#define BASE_H_

class Base {
public:
	Base( );
	virtual ~Base( );
   
   // add necessary functions here
	virtual void f1();
	virtual void f2();
};
#endif /*BASE_H*/
