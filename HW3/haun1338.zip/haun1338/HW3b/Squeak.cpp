#include <iostream>
#include <string>
#include "Squeak.h"

Squeak::Squeak( ) { }

Squeak::~Squeak( ){ }
//
void Squeak::quack( ) {std::cout << "squeak" << std::endl;}
