#include <iostream>
#include <string>
#include "NoQuack.h"

NoQuack::NoQuack( ) { }

NoQuack::~NoQuack( ){ }

void NoQuack::quack( ) {std::cout << "the sounds of silence" << std::endl;}

