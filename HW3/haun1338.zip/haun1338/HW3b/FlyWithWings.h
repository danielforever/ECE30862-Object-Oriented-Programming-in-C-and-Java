#ifndef FLYWITHWINGS_H_
#define FLYWITHWINGS_H_
#include "FlyBehavior.h"

class FlyWithWings : public FlyBehavior {
public:

// PUT CODE HERE.  Use NoFly.cpp as an example
	FlyWithWings( );
	virtual ~FlyWithWings( );
	virtual void fly( );

};
#endif /* FLYWITHWINGS_H_ */
