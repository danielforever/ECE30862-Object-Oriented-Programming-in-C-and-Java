#ifndef QUACKQUACK_H_
#define QUACKQUACK_H_
#include <string>
#include "Quack.h"

class QuackQuack : public Quack {
public:

   QuackQuack( );
   virtual ~QuackQuack( );
   virtual void quack( );
};
#endif /* QUACKQUACK_H_ */
