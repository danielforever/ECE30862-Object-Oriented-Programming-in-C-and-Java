#include <iostream>
#include "NoFly.h"


NoFly::NoFly( ) { }
NoFly::~NoFly( ) { }
void NoFly::fly( ) {
   std::cout << "I cannot fly!" << std::endl;
}
    
