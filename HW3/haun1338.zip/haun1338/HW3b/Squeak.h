#ifndef SQUEAK_H_
#define SQUEAK_H_
#include <string>
#include "Quack.h"

// PUT CODE HERE.  Use QuackQuack.h as an example.
class Squeak : public Quack {
public:
	Squeak();
	virtual ~Squeak();
	virtual void quack();
};

#endif /* SQUEAK_H_ */
